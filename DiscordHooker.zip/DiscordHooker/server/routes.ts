import type { Express } from "express";
import { createServer, type Server } from "http";
import { storage } from "./storage";
import { insertWebhookSchema, insertMessageSchema } from "@shared/schema";
import { z } from "zod";

export async function registerRoutes(app: Express): Promise<Server> {
  // Webhook routes
  app.get("/api/webhooks", async (req, res) => {
    try {
      const webhooks = await storage.getWebhooks();
      res.json(webhooks);
    } catch (error) {
      res.status(500).json({ message: "Failed to fetch webhooks" });
    }
  });

  app.post("/api/webhooks", async (req, res) => {
    try {
      const webhookData = insertWebhookSchema.parse(req.body);
      const webhook = await storage.createWebhook(webhookData);
      res.status(201).json(webhook);
    } catch (error) {
      if (error instanceof z.ZodError) {
        res.status(400).json({ message: "Invalid webhook data", errors: error.errors });
      } else {
        res.status(500).json({ message: "Failed to create webhook" });
      }
    }
  });

  app.put("/api/webhooks/:id", async (req, res) => {
    try {
      const { id } = req.params;
      const updates = insertWebhookSchema.partial().parse(req.body);
      const webhook = await storage.updateWebhook(id, updates);
      
      if (!webhook) {
        return res.status(404).json({ message: "Webhook not found" });
      }
      
      res.json(webhook);
    } catch (error) {
      if (error instanceof z.ZodError) {
        res.status(400).json({ message: "Invalid update data", errors: error.errors });
      } else {
        res.status(500).json({ message: "Failed to update webhook" });
      }
    }
  });

  app.delete("/api/webhooks/:id", async (req, res) => {
    try {
      const { id } = req.params;
      const deleted = await storage.deleteWebhook(id);
      
      if (!deleted) {
        return res.status(404).json({ message: "Webhook not found" });
      }
      
      res.status(204).send();
    } catch (error) {
      res.status(500).json({ message: "Failed to delete webhook" });
    }
  });

  // Test webhook endpoint
  app.post("/api/webhooks/:id/test", async (req, res) => {
    try {
      const { id } = req.params;
      const webhook = await storage.getWebhook(id);
      
      if (!webhook) {
        return res.status(404).json({ message: "Webhook not found" });
      }

      // Validate Discord webhook URL format
      const discordWebhookRegex = /^https:\/\/discord\.com\/api\/webhooks\/\d+\/[\w-]+$/;
      if (!discordWebhookRegex.test(webhook.url)) {
        return res.status(400).json({ message: "Invalid Discord webhook URL format" });
      }

      // Send test message to Discord
      const testPayload = {
        username: "Test Bot",
        embeds: [{
          title: "Webhook Test",
          description: "This is a test message to verify your webhook is working correctly.",
          color: 5793266, // Discord blurple
          timestamp: new Date().toISOString(),
        }]
      };

      const response = await fetch(webhook.url, {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
        },
        body: JSON.stringify(testPayload),
      });

      if (!response.ok) {
        const errorText = await response.text();
        return res.status(response.status).json({ 
          message: "Webhook test failed", 
          error: errorText 
        });
      }

      res.json({ message: "Webhook test successful" });
    } catch (error) {
      res.status(500).json({ message: "Failed to test webhook", error: error instanceof Error ? error.message : "Unknown error" });
    }
  });

  // Message routes
  app.get("/api/messages", async (req, res) => {
    try {
      const webhookId = req.query.webhookId as string;
      const messages = await storage.getMessages(webhookId);
      res.json(messages);
    } catch (error) {
      res.status(500).json({ message: "Failed to fetch messages" });
    }
  });

  app.post("/api/messages", async (req, res) => {
    try {
      const messageData = insertMessageSchema.parse(req.body);
      const message = await storage.createMessage(messageData);
      
      // Get webhook URL
      const webhook = await storage.getWebhook(messageData.webhookId!);
      if (!webhook) {
        await storage.updateMessageStatus(message.id, "failed", "Webhook not found");
        return res.status(404).json({ message: "Webhook not found" });
      }

      // Build Discord webhook payload
      const payload: any = {
        username: messageData.botUsername,
      };

      if (messageData.avatarUrl) {
        payload.avatar_url = messageData.avatarUrl;
      }

      if (messageData.embedData) {
        if (messageData.embedData.useComponents && messageData.embedData.container) {
          // Use Discord.js v2 Components
          const components = [];
          
          // Build ContainerBuilder structure
          const container: any = {};
          
          if (messageData.embedData.container.accentColor) {
            const color = messageData.embedData.container.accentColor.replace('#', '');
            container.accent_color = parseInt(color, 16);
          }
          
          // Add sections
          if (messageData.embedData.container.sections.length > 0) {
            container.sections = messageData.embedData.container.sections.map((section: any) => ({
              ...(section.title && { title: section.title }),
              ...(section.description && { description: section.description }),
              ...(section.fields && section.fields.length > 0 && { fields: section.fields }),
              ...(section.thumbnail && { thumbnail: { url: section.thumbnail.url } }),
            }));
          }
          
          // Add separators
          if (messageData.embedData.container.separators.length > 0) {
            container.separators = messageData.embedData.container.separators.map((sep: any) => ({
              spacing: sep.spacing.toLowerCase(),
              divider: sep.divider,
            }));
          }
          
          components.push(container);
          payload.components = components;
        } else {
          // Use traditional embed format
          const embed: any = {};
          
          if (messageData.embedData.title) {
            embed.title = messageData.embedData.title;
          }
          
          if (messageData.embedData.description) {
            embed.description = messageData.embedData.description;
          }
          
          if (messageData.embedData?.color) {
            // Convert hex color to decimal  
            const color = messageData.embedData.color.replace('#', '');
            embed.color = parseInt(color, 16);
          }
          
          if (messageData.embedData.fields && messageData.embedData.fields.length > 0) {
            embed.fields = messageData.embedData.fields;
          }
          
          if (messageData.embedData.image) {
            embed.image = { url: messageData.embedData.image };
          }
          
          if (messageData.embedData.timestamp) {
            embed.timestamp = new Date().toISOString();
          }

          payload.embeds = [embed];
        }
      }

      // Send to Discord
      try {
        const response = await fetch(webhook.url, {
          method: 'POST',
          headers: {
            'Content-Type': 'application/json',
          },
          body: JSON.stringify(payload),
        });

        if (!response.ok) {
          const errorText = await response.text();
          await storage.updateMessageStatus(message.id, "failed", errorText);
          return res.status(response.status).json({ 
            message: "Failed to send message to Discord", 
            error: errorText 
          });
        }

        await storage.updateMessageStatus(message.id, "sent");
        res.status(201).json(message);
      } catch (error) {
        await storage.updateMessageStatus(message.id, "failed", error instanceof Error ? error.message : "Unknown error");
        res.status(500).json({ message: "Failed to send message", error: error instanceof Error ? error.message : "Unknown error" });
      }
    } catch (error) {
      if (error instanceof z.ZodError) {
        res.status(400).json({ message: "Invalid message data", errors: error.errors });
      } else {
        res.status(500).json({ message: "Failed to create message" });
      }
    }
  });

  const httpServer = createServer(app);
  return httpServer;
}
