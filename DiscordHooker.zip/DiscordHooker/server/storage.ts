import { type Webhook, type InsertWebhook, type Message, type InsertMessage } from "@shared/schema";
import { randomUUID } from "crypto";

export interface IStorage {
  // Webhook methods
  getWebhook(id: string): Promise<Webhook | undefined>;
  getWebhooks(): Promise<Webhook[]>;
  createWebhook(webhook: InsertWebhook): Promise<Webhook>;
  updateWebhook(id: string, webhook: Partial<InsertWebhook>): Promise<Webhook | undefined>;
  deleteWebhook(id: string): Promise<boolean>;
  
  // Message methods
  getMessage(id: string): Promise<Message | undefined>;
  getMessages(webhookId?: string): Promise<Message[]>;
  createMessage(message: InsertMessage): Promise<Message>;
  updateMessageStatus(id: string, status: string, error?: string): Promise<Message | undefined>;
}

export class MemStorage implements IStorage {
  private webhooks: Map<string, Webhook>;
  private messages: Map<string, Message>;

  constructor() {
    this.webhooks = new Map();
    this.messages = new Map();
  }

  async getWebhook(id: string): Promise<Webhook | undefined> {
    return this.webhooks.get(id);
  }

  async getWebhooks(): Promise<Webhook[]> {
    return Array.from(this.webhooks.values());
  }

  async createWebhook(insertWebhook: InsertWebhook): Promise<Webhook> {
    const id = randomUUID();
    const webhook: Webhook = {
      ...insertWebhook,
      id,
      isActive: insertWebhook.isActive ?? true,
      createdAt: new Date(),
    };
    this.webhooks.set(id, webhook);
    return webhook;
  }

  async updateWebhook(id: string, updates: Partial<InsertWebhook>): Promise<Webhook | undefined> {
    const webhook = this.webhooks.get(id);
    if (!webhook) return undefined;
    
    const updated = { ...webhook, ...updates };
    this.webhooks.set(id, updated);
    return updated;
  }

  async deleteWebhook(id: string): Promise<boolean> {
    return this.webhooks.delete(id);
  }

  async getMessage(id: string): Promise<Message | undefined> {
    return this.messages.get(id);
  }

  async getMessages(webhookId?: string): Promise<Message[]> {
    const messages = Array.from(this.messages.values());
    if (webhookId) {
      return messages.filter(msg => msg.webhookId === webhookId);
    }
    return messages.sort((a, b) => new Date(b.sentAt!).getTime() - new Date(a.sentAt!).getTime());
  }

  async createMessage(insertMessage: InsertMessage): Promise<Message> {
    const id = randomUUID();
    const message: Message = {
      ...insertMessage,
      id,
      webhookId: insertMessage.webhookId || null,
      status: insertMessage.status || "pending",
      error: insertMessage.error || null,
      sentAt: new Date(),
    };
    this.messages.set(id, message);
    return message;
  }

  async updateMessageStatus(id: string, status: string, error?: string): Promise<Message | undefined> {
    const message = this.messages.get(id);
    if (!message) return undefined;
    
    const updated = { ...message, status, error: error || null };
    this.messages.set(id, updated);
    return updated;
  }
}

export const storage = new MemStorage();
