import { useState } from "react";

export default function WebhookManager() {
  const [webhookName, setWebhookName] = useState("");
  const [webhookUrl, setWebhookUrl] = useState("");
  const [botUsername, setBotUsername] = useState("WebhookBot");
  const [avatarUrl, setAvatarUrl] = useState("");
  const [embedTitle, setEmbedTitle] = useState("");
  const [description, setDescription] = useState("");
  const [color, setColor] = useState("#5865F2");
  const [messageFormat, setMessageFormat] = useState<"embed" | "components">("embed");
  const [components, setComponents] = useState<any[]>([]);
  const [useEmbedInComponents, setUseEmbedInComponents] = useState(false);

  const addComponent = (type: string) => {
    const newComponent = {
      id: Date.now(),
      type,
      data: getDefaultComponentData(type)
    };
    setComponents([...components, newComponent]);
  };

  const getDefaultComponentData = (type: string) => {
    switch (type) {
      case "container":
        return { children: [] };
      case "section":
        return { title: "Section Title", description: "Section description" };
      case "thumbnail":
        return { url: "", alt: "Thumbnail" };
      case "separator":
        return { spacing: "default" };
      case "embed":
        return { title: "Embed Title", description: "Embed description", color: "#5865F2" };
      default:
        return {};
    }
  };

  const removeComponent = (id: number) => {
    setComponents(components.filter(c => c.id !== id));
  };

  const handleSendMessage = async () => {
    if (!webhookUrl) {
      alert("Please enter a webhook URL");
      return;
    }

    const payload = messageFormat === "embed" ? {
      username: botUsername,
      avatar_url: avatarUrl || undefined,
      embeds: [{
        title: embedTitle,
        description: description,
        color: parseInt(color.replace("#", ""), 16)
      }]
    } : {
      username: botUsername,
      avatar_url: avatarUrl || undefined,
      components: components,
      embeds: useEmbedInComponents ? [{
        title: embedTitle,
        description: description,
        color: parseInt(color.replace("#", ""), 16)
      }] : undefined
    };

    try {
      const response = await fetch(webhookUrl, {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
        },
        body: JSON.stringify(payload),
      });

      if (response.ok) {
        alert("Message sent successfully!");
      } else {
        alert("Failed to send message");
      }
    } catch (error) {
      alert("Error sending message");
    }
  };

  return (
    <div className="min-h-screen bg-discord-darkest">
      {/* Header */}
      <header className="bg-discord-darker border-b border-discord-gray/20 px-4 py-3">
        <div className="max-w-7xl mx-auto flex items-center justify-between">
          <div className="flex items-center space-x-3">
            <div className="w-8 h-8 bg-discord-blurple rounded-lg flex items-center justify-center">
              <svg className="w-5 h-5 text-white" viewBox="0 0 24 24" fill="currentColor">
                <path d="M20.317 4.37a19.791 19.791 0 0 0-4.885-1.515a.074.074 0 0 0-.079.037c-.21.375-.444.864-.608 1.25a18.27 18.27 0 0 0-5.487 0a12.64 12.64 0 0 0-.617-1.25a.077.077 0 0 0-.079-.037A19.736 19.736 0 0 0 3.677 4.37a.07.07 0 0 0-.032.027C.533 9.046-.32 13.58.099 18.057a.082.082 0 0 0 .031.057a19.9 19.9 0 0 0 5.993 3.03a.078.078 0 0 0 .084-.028a14.09 14.09 0 0 0 1.226-1.994a.076.076 0 0 0-.041-.106a13.107 13.107 0 0 1-1.872-.892a.077.077 0 0 1-.008-.128a10.2 10.2 0 0 0 .372-.292a.074.074 0 0 1 .077-.01c3.928 1.793 8.18 1.793 12.062 0a.074.074 0 0 1 .078.01c.12.098.246.198.373.292a.077.077 0 0 1-.006.127a12.299 12.299 0 0 1-1.873.892a.077.077 0 0 0-.041.107c.36.698.772 1.362 1.225 1.993a.076.076 0 0 0 .084.028a19.839 19.839 0 0 0 6.002-3.03a.077.077 0 0 0 .032-.054c.5-5.177-.838-9.674-3.549-13.66a.061.061 0 0 0-.031-.03zM8.02 15.33c-1.183 0-2.157-1.085-2.157-2.419c0-1.333.956-2.419 2.157-2.419c1.21 0 2.176 1.096 2.157 2.42c0 1.333-.956 2.418-2.157 2.418zm7.975 0c-1.183 0-2.157-1.085-2.157-2.419c0-1.333.955-2.419 2.157-2.419c1.21 0 2.176 1.096 2.157 2.42c0 1.333-.946 2.418-2.157 2.418z"/>
              </svg>
            </div>
            <h1 className="text-xl font-semibold text-white">Discord Webhook Manager</h1>
          </div>
          <div className="flex items-center space-x-4">
            <button className="text-discord-text-muted hover:text-white transition-colors">
              <svg className="w-5 h-5" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M8.228 9c.549-1.165 2.03-2 3.772-2 2.21 0 4 1.343 4 3 0 1.4-1.278 2.575-3.006 2.907-.542.104-.994.54-.994 1.093m0 3h.01M21 12a9 9 0 11-18 0 9 9 0 0118 0z" />
              </svg>
            </button>
            <button className="text-discord-text-muted hover:text-white transition-colors">
              <svg className="w-5 h-5" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M10.325 4.317c.426-1.756 2.924-1.756 3.35 0a1.724 1.724 0 002.573 1.066c1.543-.94 3.31.826 2.37 2.37a1.724 1.724 0 001.065 2.572c1.756.426 1.756 2.924 0 3.35a1.724 1.724 0 00-1.066 2.573c.94 1.543-.826 3.31-2.37 2.37a1.724 1.724 0 00-2.572 1.065c-.426 1.756-2.924 1.756-3.35 0a1.724 1.724 0 00-2.573-1.066c-1.543.94-3.31-.826-2.37-2.37a1.724 1.724 0 00-1.065-2.572c-1.756-.426-1.756-2.924 0-3.35a1.724 1.724 0 001.066-2.573c-.94-1.543.826-3.31 2.37-2.37.996.608 2.296.07 2.572-1.065z" />
                <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M15 12a3 3 0 11-6 0 3 3 0 016 0z" />
              </svg>
            </button>
          </div>
        </div>
      </header>

      <div className="max-w-4xl mx-auto px-4 py-6 space-y-6">
        {/* Webhook Configuration Section */}
        <div className="bg-discord-darker rounded-lg p-6">
          <h2 className="text-xl font-semibold text-white mb-6">Discord Webhook Manager</h2>
          
          {/* Webhook URL Input */}
          <div className="space-y-4">
            <div>
              <label className="block text-sm font-medium text-discord-text mb-2">
                Webhook Name
              </label>
              <input 
                type="text" 
                placeholder="My Discord Webhook"
                value={webhookName}
                onChange={(e) => setWebhookName(e.target.value)}
                className="w-full px-3 py-2 bg-discord-darkest border border-discord-gray/30 rounded-md text-discord-text placeholder-discord-text-muted focus:outline-none focus:ring-2 focus:ring-discord-blurple"
              />
            </div>
            
            <div>
              <label className="block text-sm font-medium text-discord-text mb-2">
                Webhook URL
              </label>
              <input 
                type="url" 
                placeholder="https://discord.com/api/webhooks/..."
                value={webhookUrl}
                onChange={(e) => setWebhookUrl(e.target.value)}
                className="w-full px-3 py-2 bg-discord-darkest border border-discord-gray/30 rounded-md text-discord-text placeholder-discord-text-muted focus:outline-none focus:ring-2 focus:ring-discord-blurple"
              />
            </div>
            
            <button className="bg-discord-blurple hover:bg-discord-blurple/80 text-white px-4 py-2 rounded-md transition-colors">
              Save Webhook
            </button>
          </div>
        </div>

        {/* Message Builder Section */}
        <div className="bg-discord-darker rounded-lg p-6">
          <div className="flex items-center justify-between mb-4">
            <h3 className="text-lg font-semibold text-white">Build Your Message</h3>
            <div className="flex space-x-2">
              <button
                onClick={() => setMessageFormat("embed")}
                className={`px-3 py-1 rounded text-sm transition-colors ${
                  messageFormat === "embed"
                    ? "bg-discord-blurple text-white"
                    : "bg-discord-darkest text-discord-text hover:bg-discord-gray/30"
                }`}
              >
                Traditional Embed
              </button>
              <button
                onClick={() => setMessageFormat("components")}
                className={`px-3 py-1 rounded text-sm transition-colors ${
                  messageFormat === "components"
                    ? "bg-discord-blurple text-white"
                    : "bg-discord-darkest text-discord-text hover:bg-discord-gray/30"
                }`}
              >
                Discord.js v2 Components
              </button>
            </div>
          </div>
          
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
            {/* Form Column */}
            <div className="space-y-4">
              {/* Common Fields */}
              <div>
                <label className="block text-sm font-medium text-discord-text mb-2">
                  Bot Username
                </label>
                <input 
                  type="text" 
                  placeholder="WebhookBot"
                  value={botUsername}
                  onChange={(e) => setBotUsername(e.target.value)}
                  className="w-full px-3 py-2 bg-discord-darkest border border-discord-gray/30 rounded-md text-discord-text placeholder-discord-text-muted focus:outline-none focus:ring-2 focus:ring-discord-blurple"
                />
              </div>
              
              <div>
                <label className="block text-sm font-medium text-discord-text mb-2">
                  Avatar URL (Optional)
                </label>
                <input 
                  type="url" 
                  placeholder="https://example.com/avatar.png"
                  value={avatarUrl}
                  onChange={(e) => setAvatarUrl(e.target.value)}
                  className="w-full px-3 py-2 bg-discord-darkest border border-discord-gray/30 rounded-md text-discord-text placeholder-discord-text-muted focus:outline-none focus:ring-2 focus:ring-discord-blurple"
                />
              </div>

              {messageFormat === "embed" ? (
                <>
                  <div>
                    <label className="block text-sm font-medium text-discord-text mb-2">
                      Embed Title
                    </label>
                    <input 
                      type="text" 
                      placeholder="Your message title"
                      value={embedTitle}
                      onChange={(e) => setEmbedTitle(e.target.value)}
                      className="w-full px-3 py-2 bg-discord-darkest border border-discord-gray/30 rounded-md text-discord-text placeholder-discord-text-muted focus:outline-none focus:ring-2 focus:ring-discord-blurple"
                    />
                  </div>
                  
                  <div>
                    <label className="block text-sm font-medium text-discord-text mb-2">
                      Description
                    </label>
                    <textarea 
                      rows={4}
                      placeholder="Your message description"
                      value={description}
                      onChange={(e) => setDescription(e.target.value)}
                      className="w-full px-3 py-2 bg-discord-darkest border border-discord-gray/30 rounded-md text-discord-text placeholder-discord-text-muted focus:outline-none focus:ring-2 focus:ring-discord-blurple resize-none"
                    />
                  </div>
                  
                  <div>
                    <label className="block text-sm font-medium text-discord-text mb-2">
                      Color
                    </label>
                    <div className="flex space-x-2">
                      <input 
                        type="color" 
                        value={color}
                        onChange={(e) => setColor(e.target.value)}
                        className="w-12 h-10 bg-discord-darkest border border-discord-gray/30 rounded cursor-pointer"
                      />
                      <input 
                        type="text" 
                        placeholder="#5865F2"
                        value={color}
                        onChange={(e) => setColor(e.target.value)}
                        className="flex-1 px-3 py-2 bg-discord-darkest border border-discord-gray/30 rounded-md text-discord-text placeholder-discord-text-muted focus:outline-none focus:ring-2 focus:ring-discord-blurple"
                      />
                    </div>
                  </div>
                </>
              ) : (
                <div className="space-y-4">
                  <div>
                    <label className="block text-sm font-medium text-discord-text mb-2">
                      Discord.js v2 Components
                    </label>
                    <div className="grid grid-cols-2 gap-2">
                      <button
                        onClick={() => addComponent("container")}
                        className="px-3 py-2 bg-discord-darkest hover:bg-discord-gray/30 text-discord-text rounded text-sm transition-colors"
                      >
                        + Container
                      </button>
                      <button
                        onClick={() => addComponent("section")}
                        className="px-3 py-2 bg-discord-darkest hover:bg-discord-gray/30 text-discord-text rounded text-sm transition-colors"
                      >
                        + Section
                      </button>
                      <button
                        onClick={() => addComponent("thumbnail")}
                        className="px-3 py-2 bg-discord-darkest hover:bg-discord-gray/30 text-discord-text rounded text-sm transition-colors"
                      >
                        + Thumbnail
                      </button>
                      <button
                        onClick={() => addComponent("separator")}
                        className="px-3 py-2 bg-discord-darkest hover:bg-discord-gray/30 text-discord-text rounded text-sm transition-colors"
                      >
                        + Separator/Divider
                      </button>
                      <button
                        onClick={() => addComponent("embed")}
                        className="px-3 py-2 bg-discord-darkest hover:bg-discord-gray/30 text-discord-text rounded text-sm transition-colors"
                      >
                        + Embed
                      </button>
                    </div>
                  </div>

                  {/* Add Global Embed Option */}
                  <div className="flex items-center space-x-2">
                    <input
                      type="checkbox"
                      id="useEmbedInComponents"
                      checked={useEmbedInComponents}
                      onChange={(e) => setUseEmbedInComponents(e.target.checked)}
                      className="rounded bg-discord-darkest border-discord-gray/30"
                    />
                    <label htmlFor="useEmbedInComponents" className="text-sm text-discord-text">
                      Include main embed with components
                    </label>
                  </div>

                  {/* Show embed fields when checkbox is checked */}
                  {useEmbedInComponents && (
                    <div className="space-y-3 p-3 bg-discord-darkest rounded border border-discord-gray/20">
                      <h4 className="text-sm font-medium text-discord-text">Main Embed</h4>
                      <div>
                        <input 
                          type="text" 
                          placeholder="Embed title"
                          value={embedTitle}
                          onChange={(e) => setEmbedTitle(e.target.value)}
                          className="w-full px-2 py-1 bg-discord-darker border border-discord-gray/30 rounded text-sm text-discord-text mb-2"
                        />
                        <textarea 
                          placeholder="Embed description"
                          value={description}
                          onChange={(e) => setDescription(e.target.value)}
                          className="w-full px-2 py-1 bg-discord-darker border border-discord-gray/30 rounded text-sm text-discord-text resize-none"
                          rows={3}
                        />
                        <div className="flex space-x-2 mt-2">
                          <input 
                            type="color" 
                            value={color}
                            onChange={(e) => setColor(e.target.value)}
                            className="w-8 h-8 bg-discord-darker border border-discord-gray/30 rounded cursor-pointer"
                          />
                          <input 
                            type="text" 
                            placeholder="#5865F2"
                            value={color}
                            onChange={(e) => setColor(e.target.value)}
                            className="flex-1 px-2 py-1 bg-discord-darker border border-discord-gray/30 rounded text-sm text-discord-text"
                          />
                        </div>
                      </div>
                    </div>
                  )}

                  {/* Component List */}
                  <div className="space-y-2">
                    {components.map((component) => (
                      <div key={component.id} className="bg-discord-darkest p-3 rounded border border-discord-gray/20">
                        <div className="flex items-center justify-between mb-2">
                          <span className="text-discord-text font-medium capitalize">{component.type}</span>
                          <button
                            onClick={() => removeComponent(component.id)}
                            className="text-discord-red hover:text-red-400 text-sm"
                          >
                            Remove
                          </button>
                        </div>
                        
                        {component.type === "section" && (
                          <div className="space-y-2">
                            <input
                              type="text"
                              placeholder="Section title"
                              value={component.data.title}
                              onChange={(e) => {
                                const updated = components.map(c => 
                                  c.id === component.id 
                                    ? { ...c, data: { ...c.data, title: e.target.value } }
                                    : c
                                );
                                setComponents(updated);
                              }}
                              className="w-full px-2 py-1 bg-discord-darker border border-discord-gray/30 rounded text-sm text-discord-text"
                            />
                            <textarea
                              placeholder="Section description"
                              value={component.data.description}
                              onChange={(e) => {
                                const updated = components.map(c => 
                                  c.id === component.id 
                                    ? { ...c, data: { ...c.data, description: e.target.value } }
                                    : c
                                );
                                setComponents(updated);
                              }}
                              className="w-full px-2 py-1 bg-discord-darker border border-discord-gray/30 rounded text-sm text-discord-text resize-none"
                              rows={2}
                            />
                          </div>
                        )}
                        
                        {component.type === "thumbnail" && (
                          <input
                            type="url"
                            placeholder="Image URL"
                            value={component.data.url}
                            onChange={(e) => {
                              const updated = components.map(c => 
                                c.id === component.id 
                                  ? { ...c, data: { ...c.data, url: e.target.value } }
                                  : c
                              );
                              setComponents(updated);
                            }}
                            className="w-full px-2 py-1 bg-discord-darker border border-discord-gray/30 rounded text-sm text-discord-text"
                          />
                        )}
                        
                        {component.type === "separator" && (
                          <select
                            value={component.data.spacing}
                            onChange={(e) => {
                              const updated = components.map(c => 
                                c.id === component.id 
                                  ? { ...c, data: { ...c.data, spacing: e.target.value } }
                                  : c
                              );
                              setComponents(updated);
                            }}
                            className="w-full px-2 py-1 bg-discord-darker border border-discord-gray/30 rounded text-sm text-discord-text"
                          >
                            <option value="default">Default Spacing</option>
                            <option value="small">Small Spacing</option>
                            <option value="large">Large Spacing</option>
                          </select>
                        )}

                        {component.type === "embed" && (
                          <div className="space-y-2">
                            <input
                              type="text"
                              placeholder="Embed title"
                              value={component.data.title}
                              onChange={(e) => {
                                const updated = components.map(c => 
                                  c.id === component.id 
                                    ? { ...c, data: { ...c.data, title: e.target.value } }
                                    : c
                                );
                                setComponents(updated);
                              }}
                              className="w-full px-2 py-1 bg-discord-darker border border-discord-gray/30 rounded text-sm text-discord-text"
                            />
                            <textarea
                              placeholder="Embed description"
                              value={component.data.description}
                              onChange={(e) => {
                                const updated = components.map(c => 
                                  c.id === component.id 
                                    ? { ...c, data: { ...c.data, description: e.target.value } }
                                    : c
                                );
                                setComponents(updated);
                              }}
                              className="w-full px-2 py-1 bg-discord-darker border border-discord-gray/30 rounded text-sm text-discord-text resize-none"
                              rows={2}
                            />
                            <div className="flex space-x-2">
                              <input 
                                type="color" 
                                value={component.data.color}
                                onChange={(e) => {
                                  const updated = components.map(c => 
                                    c.id === component.id 
                                      ? { ...c, data: { ...c.data, color: e.target.value } }
                                      : c
                                  );
                                  setComponents(updated);
                                }}
                                className="w-8 h-8 bg-discord-darker border border-discord-gray/30 rounded cursor-pointer"
                              />
                              <input 
                                type="text" 
                                placeholder="#5865F2"
                                value={component.data.color}
                                onChange={(e) => {
                                  const updated = components.map(c => 
                                    c.id === component.id 
                                      ? { ...c, data: { ...c.data, color: e.target.value } }
                                      : c
                                  );
                                  setComponents(updated);
                                }}
                                className="flex-1 px-2 py-1 bg-discord-darker border border-discord-gray/30 rounded text-sm text-discord-text"
                              />
                            </div>
                          </div>
                        )}
                      </div>
                    ))}
                  </div>
                </div>
              )}
              
              <button 
                onClick={handleSendMessage}
                className="w-full bg-discord-green hover:bg-discord-green/80 text-white px-4 py-3 rounded-md transition-colors font-medium"
              >
                Send Message
              </button>
            </div>
            
            {/* Preview Column */}
            <div className="space-y-4">
              <h4 className="text-sm font-medium text-discord-text">Preview</h4>
              <div className="bg-discord-darkest rounded-lg p-4">
                <div className="flex items-center space-x-3 mb-3">
                  <div className="w-10 h-10 bg-discord-blurple rounded-full flex items-center justify-center">
                    <svg className="w-5 h-5 text-white" fill="currentColor" viewBox="0 0 24 24">
                      <path d="M12 2C6.48 2 2 6.48 2 12s4.48 10 10 10 10-4.48 10-10S17.52 2 12 2zm-2 15l-5-5 1.41-1.41L10 14.17l7.59-7.59L19 8l-9 9z"/>
                    </svg>
                  </div>
                  <div>
                    <div className="text-white font-medium">{botUsername}</div>
                    <div className="text-xs text-discord-text-muted">Today at 12:00 PM</div>
                  </div>
                </div>
                
                {messageFormat === "embed" ? (
                  <div className="border-l-4 border-discord-blurple bg-discord-dark/50 p-4 rounded-r-md" style={{ borderColor: color }}>
                    <div className="text-white font-semibold mb-2">{embedTitle || "Your message title"}</div>
                    <div className="text-discord-text text-sm">{description || "Your message description will appear here"}</div>
                  </div>
                ) : (
                  <div className="space-y-3">
                    {/* Show main embed if checkbox is checked */}
                    {useEmbedInComponents && (
                      <div className="border-l-4 border-discord-blurple bg-discord-dark/50 p-4 rounded-r-md" style={{ borderColor: color }}>
                        <div className="text-white font-semibold mb-2">{embedTitle || "Main Embed Title"}</div>
                        <div className="text-discord-text text-sm">{description || "Main embed description"}</div>
                      </div>
                    )}
                    
                    {components.length === 0 && !useEmbedInComponents ? (
                      <div className="text-discord-text-muted text-sm italic">Add components to see preview</div>
                    ) : (
                      components.map((component) => (
                        <div key={component.id} className="bg-discord-dark/50 p-3 rounded">
                          {component.type === "container" && (
                            <div className="border border-discord-gray/30 rounded p-2">
                              <div className="text-discord-text-muted text-xs">Container</div>
                            </div>
                          )}
                          {component.type === "section" && (
                            <div>
                              <div className="text-white font-medium">{component.data.title}</div>
                              <div className="text-discord-text text-sm">{component.data.description}</div>
                            </div>
                          )}
                          {component.type === "thumbnail" && component.data.url && (
                            <img 
                              src={component.data.url} 
                              alt={component.data.alt}
                              className="w-20 h-20 rounded object-cover"
                              onError={(e) => {
                                e.currentTarget.style.display = 'none';
                              }}
                            />
                          )}
                          {component.type === "separator" && (
                            <div className={`border-t border-discord-gray/30 ${
                              component.data.spacing === "small" ? "my-1" :
                              component.data.spacing === "large" ? "my-4" : "my-2"
                            }`}></div>
                          )}
                          {component.type === "embed" && (
                            <div className="border-l-4 bg-discord-dark/50 p-3 rounded-r-md" style={{ borderColor: component.data.color }}>
                              <div className="text-white font-semibold mb-1">{component.data.title}</div>
                              <div className="text-discord-text text-sm">{component.data.description}</div>
                            </div>
                          )}
                        </div>
                      ))
                    )}
                  </div>
                )}
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}