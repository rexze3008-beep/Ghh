export interface DiscordEmbed {
  title?: string;
  description?: string;
  color?: number;
  fields?: Array<{
    name: string;
    value: string;
    inline?: boolean;
  }>;
  image?: {
    url: string;
  };
  timestamp?: string;
}

export interface DiscordWebhookPayload {
  username?: string;
  avatar_url?: string;
  embeds?: DiscordEmbed[];
}

export function validateDiscordWebhookUrl(url: string): boolean {
  const discordWebhookRegex = /^https:\/\/discord\.com\/api\/webhooks\/\d+\/[\w-]+$/;
  return discordWebhookRegex.test(url);
}

export function hexToDecimal(hex: string): number {
  const cleanHex = hex.replace('#', '');
  return parseInt(cleanHex, 16);
}

export function buildDiscordPayload(
  botUsername: string,
  avatarUrl: string | undefined,
  embedData: any
): DiscordWebhookPayload {
  const payload: DiscordWebhookPayload = {
    username: botUsername,
  };

  if (avatarUrl) {
    payload.avatar_url = avatarUrl;
  }

  if (embedData) {
    const embed: DiscordEmbed = {};
    
    if (embedData.title) {
      embed.title = embedData.title;
    }
    
    if (embedData.description) {
      embed.description = embedData.description;
    }
    
    if (embedData.color) {
      embed.color = hexToDecimal(embedData.color);
    }
    
    if (embedData.fields && embedData.fields.length > 0) {
      embed.fields = embedData.fields;
    }
    
    if (embedData.image) {
      embed.image = { url: embedData.image };
    }
    
    if (embedData.timestamp) {
      embed.timestamp = new Date().toISOString();
    }

    payload.embeds = [embed];
  }

  return payload;
}
