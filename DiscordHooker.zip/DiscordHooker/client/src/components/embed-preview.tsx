import { Button } from "@/components/ui/button";
import { type EmbedData } from "@shared/schema";

interface EmbedPreviewProps {
  botUsername: string;
  avatarUrl?: string;
  embedData: EmbedData;
}

export default function EmbedPreview({ botUsername, avatarUrl, embedData }: EmbedPreviewProps) {
  const currentTime = new Date().toLocaleTimeString("en-US", {
    hour: "numeric",
    minute: "2-digit",
    hour12: true,
  });

  const hexToDecimal = (hex: string) => {
    const cleanHex = hex.replace('#', '');
    return parseInt(cleanHex, 16);
  };

  const embedJson = {
    username: botUsername || "WebhookBot",
    ...(avatarUrl && { avatar_url: avatarUrl }),
    ...(embedData.useComponents && embedData.container ? {
      components: [{
        ...(embedData.container.accentColor && { accent_color: hexToDecimal(embedData.container.accentColor) }),
        ...(embedData.container.sections && embedData.container.sections.length > 0 && {
          sections: embedData.container.sections.map(section => ({
            ...(section.title && { title: section.title }),
            ...(section.description && { description: section.description }),
            ...(section.fields && section.fields.length > 0 && { fields: section.fields }),
            ...(section.thumbnail && { thumbnail: { url: section.thumbnail.url } }),
          }))
        }),
        ...(embedData.container.separators && embedData.container.separators.length > 0 && {
          separators: embedData.container.separators.map(sep => ({
            spacing: sep.spacing.toLowerCase(),
            divider: sep.divider,
          }))
        }),
      }]
    } : {
      embeds: [{
        ...(embedData.title && { title: embedData.title }),
        ...(embedData.description && { description: embedData.description }),
        ...(embedData.color && { color: hexToDecimal(embedData.color) }),
        ...(embedData.fields && embedData.fields.length > 0 && { fields: embedData.fields }),
        ...(embedData.image && { image: { url: embedData.image } }),
        ...(embedData.timestamp && { timestamp: new Date().toISOString() }),
      }]
    })
  };

  return (
    <div>
      <h3 className="text-sm font-medium text-discord-text mb-3 flex items-center">
        <svg className="w-4 h-4 text-discord-blurple mr-2" fill="none" stroke="currentColor" viewBox="0 0 24 24">
          <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M15 12a3 3 0 11-6 0 3 3 0 016 0z" />
          <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M2.458 12C3.732 7.943 7.523 5 12 5c4.478 0 8.268 2.943 9.542 7-1.274 4.057-5.064 7-9.542 7-4.477 0-8.268-2.943-9.542-7z" />
        </svg>
        Live Preview
      </h3>
      
      <div className="bg-discord-darkest p-4 rounded-lg border border-discord-gray/20 mb-4">
        {/* Discord Message Preview */}
        <div className="flex items-start space-x-3">
          {/* Avatar */}
          <div className="w-10 h-10 bg-discord-blurple rounded-full flex items-center justify-center flex-shrink-0 overflow-hidden">
            {avatarUrl ? (
              <img src={avatarUrl} alt="Bot Avatar" className="w-full h-full object-cover" />
            ) : (
              <svg className="w-6 h-6 text-white" fill="currentColor" viewBox="0 0 24 24">
                <path d="M12 2C6.48 2 2 6.48 2 12s4.48 10 10 10 10-4.48 10-10S17.52 2 12 2zm-2 15l-5-5 1.41-1.41L10 14.17l7.59-7.59L19 8l-9 9z"/>
              </svg>
            )}
          </div>
          
          {/* Message Content */}
          <div className="flex-1 min-w-0">
            <div className="flex items-baseline space-x-2 mb-1">
              <span className="font-medium text-white">{botUsername || "WebhookBot"}</span>
              <span className="text-xs text-discord-text-muted bg-discord-blurple px-1 rounded text-white">BOT</span>
              <span className="text-xs text-discord-text-muted">Today at {currentTime}</span>
            </div>
            
            {/* Preview Content */}
            {embedData.useComponents && embedData.container ? (
              /* Discord.js v2 Components Preview */
              <div 
                className="border-l-4 bg-discord-dark/50 p-4 rounded-r-md mt-2"
                style={{ 
                  borderLeftColor: embedData.container.accentColor || "#5865F2" 
                }}
              >
                <div className="text-xs text-discord-blurple mb-2 font-medium">DISCORD.JS V2 COMPONENTS</div>
                {embedData.container.sections?.map((section, index) => (
                  <div key={index} className="mb-4">
                    {section.title && (
                      <div className="text-white font-semibold mb-2">{section.title}</div>
                    )}
                    {section.description && (
                      <div className="text-discord-text text-sm mb-3 whitespace-pre-wrap">{section.description}</div>
                    )}
                    {section.thumbnail && (
                      <div className="flex items-start space-x-3 mb-2">
                        <img 
                          src={section.thumbnail.url} 
                          alt="Thumbnail" 
                          className="w-16 h-16 rounded object-cover" 
                          onError={(e) => {
                            e.currentTarget.style.display = 'none';
                          }}
                        />
                      </div>
                    )}
                    {section.fields && section.fields.length > 0 && (
                      <div className="grid gap-2 mb-3">
                        {section.fields.map((field, fieldIndex) => (
                          <div key={fieldIndex}>
                            <div className="text-white font-medium text-sm">{field.name}</div>
                            <div className="text-discord-text text-sm whitespace-pre-wrap">{field.value}</div>
                          </div>
                        ))}
                      </div>
                    )}
                  </div>
                ))}
                {embedData.container.separators?.map((separator, index) => (
                  <div key={index} className="my-3">
                    {separator.divider && (
                      <hr className="border-discord-gray/30" />
                    )}
                    <div className={`h-${separator.spacing === 'Small' ? '2' : separator.spacing === 'Medium' ? '4' : '6'}`}></div>
                  </div>
                ))}
              </div>
            ) : (
              /* Traditional Embed Preview */
              (embedData.title || embedData.description || embedData.fields?.length || embedData.image) && (
                <div 
                  className="border-l-4 bg-discord-dark/50 p-4 rounded-r-md mt-2"
                  style={{ 
                    borderLeftColor: embedData.color || "#5865F2" 
                  }}
                >
                  {embedData.title && (
                    <div className="text-white font-semibold mb-2">{embedData.title}</div>
                  )}
                  
                  {embedData.description && (
                    <div className="text-discord-text text-sm mb-3 whitespace-pre-wrap">{embedData.description}</div>
                  )}
                  
                  {/* Fields */}
                  {embedData.fields && embedData.fields.length > 0 && (
                    <div className="grid gap-4 mb-3" style={{
                      gridTemplateColumns: embedData.fields.some(f => f.inline) 
                        ? "repeat(auto-fit, minmax(150px, 1fr))" 
                        : "1fr"
                    }}>
                      {embedData.fields.map((field, index) => (
                        <div key={index} className={field.inline ? "inline-block" : "block"}>
                          <div className="text-white font-medium text-sm">{field.name}</div>
                          <div className="text-discord-text text-sm whitespace-pre-wrap">{field.value}</div>
                        </div>
                      ))}
                    </div>
                  )}
                  
                  {/* Image */}
                  {embedData.image && (
                    <img 
                      src={embedData.image} 
                      alt="Embed image" 
                      className="rounded max-w-full h-auto mb-2" 
                      style={{ maxHeight: "300px" }}
                      onError={(e) => {
                        e.currentTarget.style.display = 'none';
                      }}
                    />
                  )}
                  
                  {embedData.timestamp && (
                    <div className="text-xs text-discord-text-muted">Today at {currentTime}</div>
                  )}
                </div>
              )
            )}
          </div>
        </div>
      </div>

      {/* JSON Preview */}
      <div>
        <div className="flex items-center justify-between mb-2">
          <h4 className="text-sm font-medium text-discord-text">JSON Payload</h4>
          <Button 
            onClick={() => {
              navigator.clipboard.writeText(JSON.stringify(embedJson, null, 2));
            }}
            variant="outline"
            size="sm"
            className="text-discord-blurple border-discord-blurple hover:bg-discord-blurple/10"
          >
            <svg className="w-3 h-3 mr-1" fill="none" stroke="currentColor" viewBox="0 0 24 24">
              <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M8 16H6a2 2 0 01-2-2V6a2 2 0 012-2h8a2 2 0 012 2v2m-6 12h8a2 2 0 002-2v-8a2 2 0 00-2-2h-8a2 2 0 00-2 2v8a2 2 0 002 2z" />
            </svg>
            Copy
          </Button>
        </div>
        <div className="bg-discord-darkest p-3 rounded-md text-xs font-mono text-discord-text-muted overflow-x-auto max-h-64 overflow-y-auto">
          <pre>{JSON.stringify(embedJson, null, 2)}</pre>
        </div>
      </div>
    </div>
  );
}
