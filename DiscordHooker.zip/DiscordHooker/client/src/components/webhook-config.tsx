import { useState } from "react";
import { useMutation, useQueryClient } from "@tanstack/react-query";
import { useForm } from "react-hook-form";
import { zodResolver } from "@hookform/resolvers/zod";
import { z } from "zod";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { useToast } from "@/hooks/use-toast";
import { apiRequest } from "@/lib/queryClient";
import { insertWebhookSchema, type Webhook } from "@shared/schema";

const webhookFormSchema = insertWebhookSchema.extend({
  url: z.string().url("Must be a valid URL").regex(
    /^https:\/\/discord\.com\/api\/webhooks\/\d+\/[\w-]+$/,
    "Must be a valid Discord webhook URL"
  ),
});

type WebhookFormData = z.infer<typeof webhookFormSchema>;

interface WebhookConfigProps {
  webhooks: Webhook[];
  selectedWebhookId: string | null;
  onWebhookSelect: (id: string | null) => void;
  isLoading: boolean;
}

export default function WebhookConfig({ 
  webhooks, 
  selectedWebhookId, 
  onWebhookSelect, 
  isLoading 
}: WebhookConfigProps) {
  const [isCreating, setIsCreating] = useState(false);
  const [testingId, setTestingId] = useState<string | null>(null);
  const { toast } = useToast();
  const queryClient = useQueryClient();

  const form = useForm<WebhookFormData>({
    resolver: zodResolver(webhookFormSchema),
    defaultValues: {
      name: "",
      url: "",
      isActive: true,
    },
  });

  const createMutation = useMutation({
    mutationFn: async (data: WebhookFormData) => {
      const res = await apiRequest("POST", "/api/webhooks", data);
      return res.json();
    },
    onSuccess: (webhook) => {
      queryClient.invalidateQueries({ queryKey: ["/api/webhooks"] });
      onWebhookSelect(webhook.id);
      setIsCreating(false);
      form.reset();
      toast({
        title: "Success",
        description: "Webhook created successfully",
      });
    },
    onError: (error: Error) => {
      toast({
        title: "Error",
        description: error.message,
        variant: "destructive",
      });
    },
  });

  const testMutation = useMutation({
    mutationFn: async (id: string) => {
      const res = await apiRequest("POST", `/api/webhooks/${id}/test`);
      return res.json();
    },
    onSuccess: () => {
      toast({
        title: "Success",
        description: "Webhook test successful",
      });
    },
    onError: (error: Error) => {
      toast({
        title: "Test Failed",
        description: error.message,
        variant: "destructive",
      });
    },
    onSettled: () => {
      setTestingId(null);
    },
  });

  const handleTest = (webhookId: string) => {
    setTestingId(webhookId);
    testMutation.mutate(webhookId);
  };

  const onSubmit = (data: WebhookFormData) => {
    createMutation.mutate(data);
  };

  const selectedWebhook = webhooks.find(w => w.id === selectedWebhookId);

  return (
    <div className="bg-discord-darker rounded-lg p-6">
      <h2 className="text-lg font-semibold text-white mb-4 flex items-center">
        <svg className="w-5 h-5 text-discord-blurple mr-2" fill="none" stroke="currentColor" viewBox="0 0 24 24">
          <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M13.828 10.172a4 4 0 00-5.656 0l-4 4a4 4 0 105.656 5.656l1.102-1.101m-.758-4.899a4 4 0 005.656 0l4-4a4 4 0 00-5.656-5.656l-1.1 1.1" />
        </svg>
        Webhook Configuration
      </h2>
      
      {!isCreating && webhooks.length > 0 && (
        <div className="mb-4">
          <Label className="block text-sm font-medium text-discord-text mb-2">Select Webhook</Label>
          <Select value={selectedWebhookId || ""} onValueChange={(value) => onWebhookSelect(value || null)}>
            <SelectTrigger className="w-full bg-discord-darkest border-discord-gray/30 text-discord-text">
              <SelectValue placeholder="Choose a webhook" />
            </SelectTrigger>
            <SelectContent className="bg-discord-darkest border-discord-gray/30">
              {webhooks.map((webhook) => (
                <SelectItem key={webhook.id} value={webhook.id} className="text-discord-text">
                  {webhook.name}
                </SelectItem>
              ))}
            </SelectContent>
          </Select>
        </div>
      )}

      {!isCreating ? (
        <>
          <Button 
            onClick={() => setIsCreating(true)}
            className="w-full bg-discord-blurple hover:bg-discord-blurple/80 text-white mb-4"
          >
            <svg className="w-4 h-4 mr-2" fill="none" stroke="currentColor" viewBox="0 0 24 24">
              <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M12 6v6m0 0v6m0-6h6m-6 0H6" />
            </svg>
            Add New Webhook
          </Button>

          {selectedWebhook && (
            <div className="space-y-3">
              <div className="p-3 bg-discord-darkest rounded-md">
                <div className="text-sm text-white mb-1">{selectedWebhook.name}</div>
                <div className="text-xs text-discord-text-muted truncate">{selectedWebhook.url}</div>
              </div>
              
              <div className="flex space-x-2">
                <Button 
                  onClick={() => handleTest(selectedWebhook.id)}
                  disabled={testingId === selectedWebhook.id}
                  className="flex-1 bg-discord-green hover:bg-discord-green/80 text-white"
                >
                  {testingId === selectedWebhook.id ? (
                    <>
                      <svg className="animate-spin w-4 h-4 mr-2" fill="none" viewBox="0 0 24 24">
                        <circle className="opacity-25" cx="12" cy="12" r="10" stroke="currentColor" strokeWidth="4"></circle>
                        <path className="opacity-75" fill="currentColor" d="M4 12a8 8 0 018-8V0C5.373 0 0 5.373 0 12h4zm2 5.291A7.962 7.962 0 014 12H0c0 3.042 1.135 5.824 3 7.938l3-2.647z"></path>
                      </svg>
                      Testing...
                    </>
                  ) : (
                    <>
                      <svg className="w-4 h-4 mr-2" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                        <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M5 13l4 4L19 7" />
                      </svg>
                      Test
                    </>
                  )}
                </Button>
              </div>

              <div className="p-3 bg-discord-green/10 border border-discord-green/20 rounded-md">
                <div className="flex items-center">
                  <svg className="w-4 h-4 text-discord-green mr-2" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                    <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M5 13l4 4L19 7" />
                  </svg>
                  <span className="text-sm text-discord-green">Webhook ready to use</span>
                </div>
              </div>
            </div>
          )}
        </>
      ) : (
        <form onSubmit={form.handleSubmit(onSubmit)} className="space-y-4">
          <div>
            <Label className="block text-sm font-medium text-discord-text mb-2">Webhook Name</Label>
            <Input 
              {...form.register("name")}
              placeholder="My Discord Webhook"
              className="w-full bg-discord-darkest border-discord-gray/30 text-discord-text placeholder-discord-text-muted"
            />
            {form.formState.errors.name && (
              <p className="text-discord-red text-xs mt-1">{form.formState.errors.name.message}</p>
            )}
          </div>
          
          <div>
            <Label className="block text-sm font-medium text-discord-text mb-2">Webhook URL</Label>
            <Input 
              {...form.register("url")}
              type="url" 
              placeholder="https://discord.com/api/webhooks/..."
              className="w-full bg-discord-darkest border-discord-gray/30 text-discord-text placeholder-discord-text-muted"
            />
            {form.formState.errors.url && (
              <p className="text-discord-red text-xs mt-1">{form.formState.errors.url.message}</p>
            )}
          </div>
          
          <div className="flex space-x-2 pt-2">
            <Button 
              type="submit" 
              disabled={createMutation.isPending}
              className="flex-1 bg-discord-blurple hover:bg-discord-blurple/80 text-white"
            >
              {createMutation.isPending ? (
                <>
                  <svg className="animate-spin w-4 h-4 mr-2" fill="none" viewBox="0 0 24 24">
                    <circle className="opacity-25" cx="12" cy="12" r="10" stroke="currentColor" strokeWidth="4"></circle>
                    <path className="opacity-75" fill="currentColor" d="M4 12a8 8 0 018-8V0C5.373 0 0 5.373 0 12h4zm2 5.291A7.962 7.962 0 014 12H0c0 3.042 1.135 5.824 3 7.938l3-2.647z"></path>
                  </svg>
                  Creating...
                </>
              ) : (
                <>
                  <svg className="w-4 h-4 mr-2" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                    <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M8 7H5a2 2 0 00-2 2v9a2 2 0 002 2h14a2 2 0 002-2V9a2 2 0 00-2-2h-3m-1 4l-3 3m0 0l-3-3m3 3V4" />
                  </svg>
                  Save
                </>
              )}
            </Button>
            <Button 
              type="button" 
              onClick={() => {
                setIsCreating(false);
                form.reset();
              }}
              variant="outline"
              className="px-4 bg-discord-gray hover:bg-discord-gray/80 text-white border-discord-gray/30"
            >
              Cancel
            </Button>
          </div>
        </form>
      )}
    </div>
  );
}
