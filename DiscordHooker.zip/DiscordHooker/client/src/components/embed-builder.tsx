import { useState } from "react";
import { useForm, useFieldArray } from "react-hook-form";
import { zodResolver } from "@hookform/resolvers/zod";
import { useMutation, useQueryClient } from "@tanstack/react-query";
import { z } from "zod";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import { Checkbox } from "@/components/ui/checkbox";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Switch } from "@/components/ui/switch";
import { useToast } from "@/hooks/use-toast";
import { apiRequest } from "@/lib/queryClient";
import { insertMessageSchema, type Webhook, type EmbedField } from "@shared/schema";
import EmbedPreview from "./embed-preview";

const embedBuilderSchema = insertMessageSchema.omit({ webhookId: true }).extend({
  embedData: z.object({
    title: z.string().optional(),
    description: z.string().optional(),
    color: z.string().optional(),
    fields: z.array(z.object({
      name: z.string(),
      value: z.string(),
      inline: z.boolean().default(false),
    })).default([]),
    image: z.string().optional(),
    timestamp: z.boolean().default(false),
    useComponents: z.boolean().default(false),
    container: z.object({
      accentColor: z.string().optional(),
      sections: z.array(z.object({
        title: z.string().optional(),
        description: z.string().optional(),
        fields: z.array(z.object({
          name: z.string(),
          value: z.string(),
          inline: z.boolean().default(false),
        })).default([]),
        thumbnail: z.object({
          url: z.string(),
        }).optional(),
      })).default([]),
      separators: z.array(z.object({
        spacing: z.enum(['Small', 'Medium', 'Large']).default('Medium'),
        divider: z.boolean().default(false),
      })).default([]),
    }).optional(),
  }).optional(),
});

type EmbedBuilderData = z.infer<typeof embedBuilderSchema>;

interface EmbedBuilderProps {
  webhook: Webhook | undefined;
}

export default function EmbedBuilder({ webhook }: EmbedBuilderProps) {
  const { toast } = useToast();
  const queryClient = useQueryClient();

  const form = useForm<EmbedBuilderData>({
    resolver: zodResolver(embedBuilderSchema),
    defaultValues: {
      botUsername: "WebhookBot",
      avatarUrl: "",
      embedData: {
        title: "",
        description: "",
        color: "#5865F2",
        fields: [],
        image: "",
        timestamp: true,
        useComponents: false,
        container: {
          accentColor: "#5865F2",
          sections: [],
          separators: [],
        },
      },
      status: "pending",
    },
  });

  const { fields, append, remove } = useFieldArray({
    control: form.control,
    name: "embedData.fields",
  });

  const { fields: sections, append: appendSection, remove: removeSection } = useFieldArray({
    control: form.control,
    name: "embedData.container.sections",
  });

  const { fields: separators, append: appendSeparator, remove: removeSeparator } = useFieldArray({
    control: form.control,
    name: "embedData.container.separators",
  });

  const sendMutation = useMutation({
    mutationFn: async (data: EmbedBuilderData & { webhookId: string }) => {
      const res = await apiRequest("POST", "/api/messages", data);
      return res.json();
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/messages"] });
      toast({
        title: "Success",
        description: "Message sent successfully",
      });
    },
    onError: (error: Error) => {
      toast({
        title: "Error",
        description: error.message,
        variant: "destructive",
      });
    },
  });

  const onSubmit = (data: EmbedBuilderData) => {
    if (!webhook) {
      toast({
        title: "Error",
        description: "Please select a webhook first",
        variant: "destructive",
      });
      return;
    }

    sendMutation.mutate({
      ...data,
      webhookId: webhook.id,
    });
  };

  const addField = () => {
    append({ name: "", value: "", inline: false });
  };

  const addSection = () => {
    appendSection({ 
      title: "", 
      description: "", 
      fields: [], 
      thumbnail: undefined 
    });
  };

  const addSeparator = () => {
    appendSeparator({ spacing: "Medium", divider: true });
  };

  const clearForm = () => {
    form.reset();
  };

  const watchedValues = form.watch();

  if (!webhook) {
    return (
      <div className="bg-discord-darker rounded-lg p-6">
        <h2 className="text-lg font-semibold text-white mb-6 flex items-center">
          <svg className="w-5 h-5 text-discord-blurple mr-2" fill="none" stroke="currentColor" viewBox="0 0 24 24">
            <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M11 5H6a2 2 0 00-2 2v11a2 2 0 002 2h11a2 2 0 002-2v-5m-1.414-9.414a2 2 0 112.828 2.828L11.828 15H9v-2.828l8.586-8.586z" />
          </svg>
          Embed Message Builder
        </h2>
        <div className="text-center py-12">
          <svg className="w-16 h-16 text-discord-text-muted mx-auto mb-4" fill="none" stroke="currentColor" viewBox="0 0 24 24">
            <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M13.828 10.172a4 4 0 00-5.656 0l-4 4a4 4 0 105.656 5.656l1.102-1.101m-.758-4.899a4 4 0 005.656 0l4-4a4 4 0 00-5.656-5.656l-1.1 1.1" />
          </svg>
          <p className="text-discord-text-muted">Please select or create a webhook to start building messages</p>
        </div>
      </div>
    );
  }

  return (
    <div className="bg-discord-darker rounded-lg p-6">
      <h2 className="text-lg font-semibold text-white mb-6 flex items-center">
        <svg className="w-5 h-5 text-discord-blurple mr-2" fill="none" stroke="currentColor" viewBox="0 0 24 24">
          <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M11 5H6a2 2 0 00-2 2v11a2 2 0 002 2h11a2 2 0 002-2v-5m-1.414-9.414a2 2 0 112.828 2.828L11.828 15H9v-2.828l8.586-8.586z" />
        </svg>
        Embed Message Builder
      </h2>

      <div className="grid grid-cols-1 xl:grid-cols-2 gap-6">
        {/* Form Section */}
        <div className="space-y-4">
          <form onSubmit={form.handleSubmit(onSubmit)} className="space-y-4">
            <div>
              <Label className="block text-sm font-medium text-discord-text mb-2">Bot Username</Label>
              <Input 
                {...form.register("botUsername")}
                placeholder="WebhookBot"
                className="w-full bg-discord-darkest border-discord-gray/30 text-discord-text placeholder-discord-text-muted"
              />
            </div>

            <div>
              <Label className="block text-sm font-medium text-discord-text mb-2">Avatar URL (Optional)</Label>
              <Input 
                {...form.register("avatarUrl")}
                type="url" 
                placeholder="https://example.com/avatar.png"
                className="w-full bg-discord-darkest border-discord-gray/30 text-discord-text placeholder-discord-text-muted"
              />
            </div>

            <div>
              <Label className="block text-sm font-medium text-discord-text mb-2">Embed Title</Label>
              <Input 
                {...form.register("embedData.title")}
                placeholder="Enter your embed title"
                className="w-full bg-discord-darkest border-discord-gray/30 text-discord-text placeholder-discord-text-muted"
              />
            </div>

            <div>
              <Label className="block text-sm font-medium text-discord-text mb-2">Description</Label>
              <Textarea 
                {...form.register("embedData.description")}
                rows={4} 
                placeholder="Enter your embed description"
                className="w-full bg-discord-darkest border-discord-gray/30 text-discord-text placeholder-discord-text-muted resize-none"
              />
            </div>

            <div className="grid grid-cols-2 gap-4">
              <div>
                <Label className="block text-sm font-medium text-discord-text mb-2">Color</Label>
                <div className="flex space-x-2">
                  <Input 
                    {...form.register("embedData.color")}
                    type="color" 
                    className="w-12 h-10 bg-discord-darkest border-discord-gray/30 cursor-pointer p-1"
                  />
                  <Input 
                    {...form.register("embedData.color")}
                    placeholder="#5865F2"
                    className="flex-1 bg-discord-darkest border-discord-gray/30 text-discord-text placeholder-discord-text-muted"
                  />
                </div>
              </div>

              <div>
                <Label className="block text-sm font-medium text-discord-text mb-2">Timestamp</Label>
                <Select 
                  value={form.watch("embedData.timestamp") ? "current" : "none"}
                  onValueChange={(value) => form.setValue("embedData.timestamp", value === "current")}
                >
                  <SelectTrigger className="w-full bg-discord-darkest border-discord-gray/30 text-discord-text">
                    <SelectValue />
                  </SelectTrigger>
                  <SelectContent className="bg-discord-darkest border-discord-gray/30">
                    <SelectItem value="none" className="text-discord-text">None</SelectItem>
                    <SelectItem value="current" className="text-discord-text">Current Time</SelectItem>
                  </SelectContent>
                </Select>
              </div>
            </div>

            <div>
              <Label className="block text-sm font-medium text-discord-text mb-2">Image URL (Optional)</Label>
              <Input 
                {...form.register("embedData.image")}
                type="url" 
                placeholder="https://example.com/image.png"
                className="w-full bg-discord-darkest border-discord-gray/30 text-discord-text placeholder-discord-text-muted"
              />
            </div>

            {/* Discord.js v2 Components Toggle */}
            <div className="border-t border-discord-gray/20 pt-4">
              <div className="flex items-center justify-between mb-4">
                <div>
                  <Label className="text-sm font-medium text-discord-text">Discord.js v2 Components</Label>
                  <p className="text-xs text-discord-text-muted">Use new Discord components format</p>
                </div>
                <Switch
                  checked={form.watch("embedData.useComponents")}
                  onCheckedChange={(checked) => form.setValue("embedData.useComponents", checked)}
                />
              </div>

              {form.watch("embedData.useComponents") && (
                <div className="space-y-4 p-4 bg-discord-darkest rounded-md">
                  <div>
                    <Label className="block text-sm font-medium text-discord-text mb-2">Container Accent Color</Label>
                    <div className="flex space-x-2">
                      <Input 
                        {...form.register("embedData.container.accentColor")}
                        type="color" 
                        className="w-12 h-10 bg-discord-darkest border-discord-gray/30 cursor-pointer p-1"
                      />
                      <Input 
                        {...form.register("embedData.container.accentColor")}
                        placeholder="#5865F2"
                        className="flex-1 bg-discord-dark border-discord-gray/30 text-discord-text placeholder-discord-text-muted"
                      />
                    </div>
                  </div>

                  {/* Sections */}
                  <div>
                    <div className="flex items-center justify-between mb-3">
                      <Label className="text-sm font-medium text-discord-text">Sections</Label>
                      <Button 
                        type="button" 
                        onClick={addSection}
                        variant="outline"
                        size="sm"
                        className="text-discord-blurple border-discord-blurple hover:bg-discord-blurple/10"
                      >
                        <svg className="w-4 h-4 mr-1" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                          <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M12 6v6m0 0v6m0-6h6m-6 0H6" />
                        </svg>
                        Add Section
                      </Button>
                    </div>
                    {sections.map((section, sectionIndex) => (
                      <div key={section.id} className="bg-discord-dark p-3 rounded-md mb-3">
                        <div className="space-y-2">
                          <Input 
                            {...form.register(`embedData.container.sections.${sectionIndex}.title`)}
                            placeholder="Section Title"
                            className="w-full bg-discord-darker border-discord-gray/30 text-discord-text placeholder-discord-text-muted"
                          />
                          <Textarea 
                            {...form.register(`embedData.container.sections.${sectionIndex}.description`)}
                            placeholder="Section Description"
                            rows={2}
                            className="w-full bg-discord-darker border-discord-gray/30 text-discord-text placeholder-discord-text-muted resize-none"
                          />
                          <Input 
                            {...form.register(`embedData.container.sections.${sectionIndex}.thumbnail.url`)}
                            placeholder="Thumbnail URL (Optional)"
                            className="w-full bg-discord-darker border-discord-gray/30 text-discord-text placeholder-discord-text-muted"
                          />
                          <Button 
                            type="button"
                            onClick={() => removeSection(sectionIndex)}
                            variant="outline"
                            size="sm"
                            className="text-discord-red border-discord-red hover:bg-discord-red/10"
                          >
                            Remove Section
                          </Button>
                        </div>
                      </div>
                    ))}
                  </div>

                  {/* Separators */}
                  <div>
                    <div className="flex items-center justify-between mb-3">
                      <Label className="text-sm font-medium text-discord-text">Separators</Label>
                      <Button 
                        type="button" 
                        onClick={addSeparator}
                        variant="outline"
                        size="sm"
                        className="text-discord-blurple border-discord-blurple hover:bg-discord-blurple/10"
                      >
                        <svg className="w-4 h-4 mr-1" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                          <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M20 12H4" />
                        </svg>
                        Add Separator
                      </Button>
                    </div>
                    {separators.map((separator, separatorIndex) => (
                      <div key={separator.id} className="bg-discord-dark p-3 rounded-md mb-3 flex items-center space-x-3">
                        <Select 
                          value={form.watch(`embedData.container.separators.${separatorIndex}.spacing`)}
                          onValueChange={(value) => form.setValue(`embedData.container.separators.${separatorIndex}.spacing`, value as "Small" | "Medium" | "Large")}
                        >
                          <SelectTrigger className="w-32 bg-discord-darker border-discord-gray/30 text-discord-text">
                            <SelectValue />
                          </SelectTrigger>
                          <SelectContent className="bg-discord-darkest border-discord-gray/30">
                            <SelectItem value="Small" className="text-discord-text">Small</SelectItem>
                            <SelectItem value="Medium" className="text-discord-text">Medium</SelectItem>
                            <SelectItem value="Large" className="text-discord-text">Large</SelectItem>
                          </SelectContent>
                        </Select>
                        <div className="flex items-center space-x-2">
                          <Checkbox 
                            id={`divider-${separatorIndex}`}
                            checked={form.watch(`embedData.container.separators.${separatorIndex}.divider`) || false}
                            onCheckedChange={(checked) => 
                              form.setValue(`embedData.container.separators.${separatorIndex}.divider`, checked === true)
                            }
                          />
                          <Label htmlFor={`divider-${separatorIndex}`} className="text-xs text-discord-text-muted">
                            Show Divider
                          </Label>
                        </div>
                        <Button 
                          type="button"
                          onClick={() => removeSeparator(separatorIndex)}
                          variant="outline"
                          size="sm"
                          className="text-discord-red border-discord-red hover:bg-discord-red/10"
                        >
                          Remove
                        </Button>
                      </div>
                    ))}
                  </div>
                </div>
              )}
            </div>

            {/* Embed Fields */}
            <div>
              <div className="flex items-center justify-between mb-3">
                <Label className="text-sm font-medium text-discord-text">Embed Fields</Label>
                <Button 
                  type="button" 
                  onClick={addField}
                  variant="outline"
                  size="sm"
                  className="text-discord-blurple border-discord-blurple hover:bg-discord-blurple/10"
                >
                  <svg className="w-4 h-4 mr-1" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                    <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M12 6v6m0 0v6m0-6h6m-6 0H6" />
                  </svg>
                  Add Field
                </Button>
              </div>
              
              <div className="space-y-3">
                {fields.map((field, index) => (
                  <div key={field.id} className="bg-discord-darkest p-3 rounded-md">
                    <div className="grid grid-cols-1 gap-2">
                      <Input 
                        {...form.register(`embedData.fields.${index}.name`)}
                        placeholder="Field Name"
                        className="w-full bg-discord-dark border-discord-gray/30 text-discord-text placeholder-discord-text-muted"
                      />
                      <Input 
                        {...form.register(`embedData.fields.${index}.value`)}
                        placeholder="Field Value"
                        className="w-full bg-discord-dark border-discord-gray/30 text-discord-text placeholder-discord-text-muted"
                      />
                      <div className="flex items-center justify-between">
                        <div className="flex items-center space-x-2">
                          <Checkbox 
                            id={`inline-${index}`}
                            checked={form.watch(`embedData.fields.${index}.inline`) || false}
                            onCheckedChange={(checked) => 
                              form.setValue(`embedData.fields.${index}.inline`, checked === true)
                            }
                          />
                          <Label htmlFor={`inline-${index}`} className="text-xs text-discord-text-muted">
                            Inline
                          </Label>
                        </div>
                        <Button 
                          type="button"
                          onClick={() => remove(index)}
                          variant="outline"
                          size="sm"
                          className="text-discord-red border-discord-red hover:bg-discord-red/10"
                        >
                          <svg className="w-3 h-3" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                            <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M19 7l-.867 12.142A2 2 0 0116.138 21H7.862a2 2 0 01-1.995-1.858L5 7m5 4v6m4-6v6m1-10V4a1 1 0 00-1-1h-4a1 1 0 00-1 1v3M4 7h16" />
                          </svg>
                        </Button>
                      </div>
                    </div>
                  </div>
                ))}
              </div>
            </div>

            <div className="flex space-x-3 pt-4">
              <Button 
                type="submit" 
                disabled={sendMutation.isPending}
                className="flex-1 bg-discord-blurple hover:bg-discord-blurple/80 text-white"
              >
                {sendMutation.isPending ? (
                  <>
                    <svg className="animate-spin w-4 h-4 mr-2" fill="none" viewBox="0 0 24 24">
                      <circle className="opacity-25" cx="12" cy="12" r="10" stroke="currentColor" strokeWidth="4"></circle>
                      <path className="opacity-75" fill="currentColor" d="M4 12a8 8 0 018-8V0C5.373 0 0 5.373 0 12h4zm2 5.291A7.962 7.962 0 014 12H0c0 3.042 1.135 5.824 3 7.938l3-2.647z"></path>
                    </svg>
                    Sending...
                  </>
                ) : (
                  <>
                    <svg className="w-4 h-4 mr-2" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                      <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M12 19l9 2-9-18-9 18 9-2zm0 0v-8" />
                    </svg>
                    Send Message
                  </>
                )}
              </Button>
              <Button 
                type="button" 
                onClick={clearForm}
                variant="outline"
                className="px-4 bg-discord-gray hover:bg-discord-gray/80 text-white border-discord-gray/30"
              >
                <svg className="w-4 h-4" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                  <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M19 7l-.867 12.142A2 2 0 0116.138 21H7.862a2 2 0 01-1.995-1.858L5 7m5 4v6m4-6v6m1-10V4a1 1 0 00-1-1h-4a1 1 0 00-1 1v3M4 7h16" />
                </svg>
              </Button>
            </div>
          </form>
        </div>

        {/* Preview Section */}
        <EmbedPreview 
          botUsername={watchedValues.botUsername || "WebhookBot"}
          avatarUrl={watchedValues.avatarUrl || undefined}
          embedData={watchedValues.embedData || { 
            fields: [], 
            timestamp: false, 
            useComponents: false,
            title: undefined,
            description: undefined,
            color: undefined,
            image: undefined,
            container: undefined
          }}
        />
      </div>
    </div>
  );
}
